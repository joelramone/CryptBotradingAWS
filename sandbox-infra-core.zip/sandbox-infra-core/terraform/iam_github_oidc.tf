variable "enable_github_oidc" {
  type    = bool
  default = true
}

variable "github_org" {
  type = string
}

variable "github_repo" {
  type = string
}

variable "github_ref_patterns" {
  type    = list(string)
  default = ["refs/heads/main"]
}

# Backwards-compat for existing trust toggles in iam_deployer.tf
variable "enable_trust_github_oidc" {
  type    = bool
  default = true
}
