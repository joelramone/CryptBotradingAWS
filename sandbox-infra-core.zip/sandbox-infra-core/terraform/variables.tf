variable "project_name" {
  type    = string
  default = "CryptoBotradingAWS"
}

variable "environment" {
  type = string
}

variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "tf_state_bucket" {
  type = string
}

variable "tf_lock_table" {
  type = string
}

variable "common_tags" {
  type    = map(string)
  default = {}
}
