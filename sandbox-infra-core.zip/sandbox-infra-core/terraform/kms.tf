resource "aws_kms_key" "core" {
  description             = "KMS key for CryptoBotradingAWS Infra Core"
  deletion_window_in_days = 7
  tags                    = local.tags
}

resource "aws_kms_alias" "core_alias" {
  name          = "alias/${var.project_name}-${var.environment}-core"
  target_key_id = aws_kms_key.core.key_id
}
