output "lambda_base_role_arn" {
  value = aws_iam_role.lambda_base.arn
}

output "kms_key_arn" {
  value = aws_kms_key.core.arn
}

output "core_secret_arn" {
  value = aws_secretsmanager_secret.core.arn
}
