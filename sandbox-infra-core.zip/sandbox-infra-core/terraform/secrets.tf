resource "aws_secretsmanager_secret" "core" {
  name        = "${var.project_name}/${var.environment}/core"
  description = "Core secrets placeholder"
  kms_key_id  = aws_kms_key.core.arn
  tags        = local.tags
}
